<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_SIGN IN</name>
   <tag></tag>
   <elementGuidId>bbe4e7f4-c649-4bd8-8100-a1d2c87e3638</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>button.ant-btn.css-1i536d8.ant-btn-primary > span</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div/section/div/div/div[2]/div[2]/form/div[4]/button/span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>4aaf3ff3-c42f-48f3-b132-fa270236e8b3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>SIGN IN</value>
      <webElementGuid>f2066b4a-af10-42f6-aec0-e487123787b9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[@class=&quot;App&quot;]/section[@class=&quot;ant-layout css-1i536d8&quot;]/div[@class=&quot;box&quot;]/div[@class=&quot;ant-row row-main css-1i536d8&quot;]/div[@class=&quot;ant-col ant-col-13 col-2 css-1i536d8&quot;]/div[@class=&quot;form-input&quot;]/form[1]/div[@class=&quot;btn-submit&quot;]/button[@class=&quot;ant-btn css-1i536d8 ant-btn-primary&quot;]/span[1]</value>
      <webElementGuid>65d6c9f1-5f52-4de8-bffc-e4823931eb0f</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div/section/div/div/div[2]/div[2]/form/div[4]/button/span</value>
      <webElementGuid>ddb1e730-208a-4343-ab2d-7beed3298aab</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Keep me signed in'])[1]/following::span[1]</value>
      <webElementGuid>318f5e39-855d-4a81-a82f-17f6ac7bd83a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Password'])[1]/following::span[2]</value>
      <webElementGuid>8e28f12f-fb81-4c43-a9ed-18a61f6763a6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Reset Password'])[1]/preceding::span[1]</value>
      <webElementGuid>94a4b959-15ad-439a-a51c-066622080751</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='SIGN IN']/parent::*</value>
      <webElementGuid>08a5d5d7-6629-49c6-a928-ddc13966f91b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//button/span</value>
      <webElementGuid>399c24c3-4032-476c-9430-d1c90b315671</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'SIGN IN' or . = 'SIGN IN')]</value>
      <webElementGuid>b8d95853-4c61-41a9-a58e-4df0213e248e</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
