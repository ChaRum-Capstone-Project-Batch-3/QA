<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Lihat Topik</name>
   <tag></tag>
   <elementGuidId>ceaf1e40-6868-4f15-bdd2-f7d366cff43d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div/section/section/section/main/div/div/div/div/button/span</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>button.ant-btn.css-1i536d8.ant-btn-primary.ant-btn-lg.btn-header > span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>fa94388e-2b57-4ea8-8388-c7f179459ded</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Lihat Topik</value>
      <webElementGuid>d31143f9-a225-4d85-bbec-b36260adda1e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[@class=&quot;App&quot;]/section[@class=&quot;ant-layout css-1i536d8&quot;]/section[@class=&quot;ant-layout ant-layout-has-sider css-1i536d8&quot;]/section[@class=&quot;ant-layout site-layout css-1i536d8&quot;]/main[@class=&quot;ant-layout-content&quot;]/div[@class=&quot;site-layout-background&quot;]/div[@class=&quot;content-main&quot;]/div[@class=&quot;header-content&quot;]/div[@class=&quot;text-head-content&quot;]/button[@class=&quot;ant-btn css-1i536d8 ant-btn-primary ant-btn-lg btn-header&quot;]/span[1]</value>
      <webElementGuid>ec49585e-0e16-469d-af44-66a1036d9173</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div/section/section/section/main/div/div/div/div/button/span</value>
      <webElementGuid>17a6b3c6-66ee-4a92-810d-4311155ac627</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Hello Vinka!'])[1]/following::span[1]</value>
      <webElementGuid>15855ded-bf91-4389-9a27-7aa7d2052bea</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='/'])[1]/following::span[2]</value>
      <webElementGuid>3da0c271-c624-4f56-b3e0-36456ad4388a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Lihat Topik']/parent::*</value>
      <webElementGuid>77d4c93c-74d8-497f-a541-43a01a29d07e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//button/span</value>
      <webElementGuid>3ca3b39e-a40a-4bd9-b511-9e6b403c6b45</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Lihat Topik' or . = 'Lihat Topik')]</value>
      <webElementGuid>e9cdd852-8d4a-46ae-80e9-dcd73348e6a6</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
