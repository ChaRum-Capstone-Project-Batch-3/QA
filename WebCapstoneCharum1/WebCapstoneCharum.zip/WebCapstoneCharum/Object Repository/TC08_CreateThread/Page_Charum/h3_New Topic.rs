<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h3_New Topic</name>
   <tag></tag>
   <elementGuidId>d9d1d714-4d85-4f3e-aa74-29310ac18a7a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div/section/section/section/main/div/div/div/h3</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>h3.ant-typography.css-1i536d8</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h3</value>
      <webElementGuid>be527b9e-ba6d-41cc-8919-2f199537c407</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>ant-typography css-1i536d8</value>
      <webElementGuid>f295dd73-e7ad-444d-9d27-00c506510290</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>New Topic</value>
      <webElementGuid>a48d4d67-20b4-4145-b92a-7bd58e2a9338</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[@class=&quot;App&quot;]/section[@class=&quot;ant-layout css-1i536d8&quot;]/section[@class=&quot;ant-layout ant-layout-has-sider css-1i536d8&quot;]/section[@class=&quot;ant-layout site-layout css-1i536d8&quot;]/main[@class=&quot;ant-layout-content&quot;]/div[@class=&quot;site-layout-background&quot;]/div[@class=&quot;content-main&quot;]/div[@class=&quot;add-topic&quot;]/h3[@class=&quot;ant-typography css-1i536d8&quot;]</value>
      <webElementGuid>09b5629f-d298-4bcd-a13e-31639662e3c9</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div/section/section/section/main/div/div/div/h3</value>
      <webElementGuid>86ec2d4f-955d-414a-8220-afdf65cc3a39</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='/'])[2]/following::h3[1]</value>
      <webElementGuid>cdf69bea-a4a8-40f7-9e17-eb3d7f073d50</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Topic'])[1]/following::h3[1]</value>
      <webElementGuid>f6ee616c-a355-46db-a4db-2746905a6fea</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Create new topic'])[1]/preceding::h3[1]</value>
      <webElementGuid>a3a36567-c967-44f7-a8db-17f61bc96ba8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='All Topic'])[1]/preceding::h3[1]</value>
      <webElementGuid>1c7d928d-f072-4ece-a7ea-f7968f9c9434</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='New Topic']/parent::*</value>
      <webElementGuid>8424b048-7a5e-4db7-8791-f72d79664906</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//h3</value>
      <webElementGuid>d62be090-b359-46cc-b48f-9bf736215f3f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h3[(text() = 'New Topic' or . = 'New Topic')]</value>
      <webElementGuid>84cb89ed-3291-4979-9180-59d88eb40792</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
