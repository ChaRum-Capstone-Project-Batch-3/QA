<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_SIGN IN</name>
   <tag></tag>
   <elementGuidId>9b8b5064-1349-4632-a6ae-1730e3e499c3</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div/section/div/div/div[2]/div[2]/form/div[4]/button/span</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>button.ant-btn.css-1i536d8.ant-btn-primary > span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>aace9fa3-b01b-4d0a-9099-56155f9e02a3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>SIGN IN</value>
      <webElementGuid>2d134e1f-8865-425b-93f7-7c72788a45e7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[@class=&quot;App&quot;]/section[@class=&quot;ant-layout css-1i536d8&quot;]/div[@class=&quot;box&quot;]/div[@class=&quot;ant-row row-main css-1i536d8&quot;]/div[@class=&quot;ant-col ant-col-13 col-2 css-1i536d8&quot;]/div[@class=&quot;form-input&quot;]/form[1]/div[@class=&quot;btn-submit&quot;]/button[@class=&quot;ant-btn css-1i536d8 ant-btn-primary&quot;]/span[1]</value>
      <webElementGuid>940896e9-2570-4a25-95f0-03fbc94e1236</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div/section/div/div/div[2]/div[2]/form/div[4]/button/span</value>
      <webElementGuid>7b717319-0093-40dc-aa7b-c3bfb536df7e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Keep me signed in'])[1]/following::span[1]</value>
      <webElementGuid>f5c089a4-4a71-4cf5-9a51-8f765b931e3c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Password'])[1]/following::span[2]</value>
      <webElementGuid>670ca147-5225-4b2b-b77a-8b1f1016cab4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Reset Password'])[1]/preceding::span[1]</value>
      <webElementGuid>5dbf3fc9-df93-4897-b79c-afe5147d4099</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='SIGN IN']/parent::*</value>
      <webElementGuid>bbb1e990-89be-481d-bd73-280291392f79</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//button/span</value>
      <webElementGuid>1369d7e2-81a8-4e50-af88-c0c079da5bc5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'SIGN IN' or . = 'SIGN IN')]</value>
      <webElementGuid>5dc8dc9d-d89a-412a-8902-502f3f0a350b</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
