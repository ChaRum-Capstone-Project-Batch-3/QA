<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_SIGN IN</name>
   <tag></tag>
   <elementGuidId>1dda7892-27df-4b85-9d23-0804ae7f3857</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>button.ant-btn.css-1i536d8.ant-btn-primary > span</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div/section/div/div/div[2]/div[2]/form/div[4]/button/span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>e11605f1-5b34-4c87-b696-e679d4146a27</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>SIGN IN</value>
      <webElementGuid>5c239f66-b3e6-4fa7-90ce-6629f701bdce</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[@class=&quot;App&quot;]/section[@class=&quot;ant-layout css-1i536d8&quot;]/div[@class=&quot;box&quot;]/div[@class=&quot;ant-row row-main css-1i536d8&quot;]/div[@class=&quot;ant-col ant-col-13 col-2 css-1i536d8&quot;]/div[@class=&quot;form-input&quot;]/form[1]/div[@class=&quot;btn-submit&quot;]/button[@class=&quot;ant-btn css-1i536d8 ant-btn-primary&quot;]/span[1]</value>
      <webElementGuid>a86eeee1-51eb-4107-af28-6e6d48403dd7</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div/section/div/div/div[2]/div[2]/form/div[4]/button/span</value>
      <webElementGuid>f1db1a0e-562d-4d65-a162-d80b9044d665</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Keep me signed in'])[1]/following::span[1]</value>
      <webElementGuid>545271a7-d5b1-4b44-9fc7-a5d68acc9ef5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Password'])[1]/following::span[2]</value>
      <webElementGuid>01dfa488-b344-4b04-ba60-f2a0128e269a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Reset Password'])[1]/preceding::span[1]</value>
      <webElementGuid>fe10b9b4-056f-4332-8c5d-b4014ed786e6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='SIGN IN']/parent::*</value>
      <webElementGuid>793421be-4d99-46f2-b8a1-5cc495ecbb56</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//button/span</value>
      <webElementGuid>d923098f-f2bd-497c-acca-64ea324527ee</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'SIGN IN' or . = 'SIGN IN')]</value>
      <webElementGuid>ca44a9b7-a9dd-4085-87e6-4be6b4364bbe</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
