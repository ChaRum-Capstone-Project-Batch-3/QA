<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Manage Users</name>
   <tag></tag>
   <elementGuidId>65e5072a-1479-4325-b71e-01ceb82735af</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div/section/section/aside/div/ul/li[3]/span[2]/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>li.ant-menu-item.ant-menu-item-active > span.ant-menu-title-content > a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>0ebc06e9-07e4-4300-9594-be5db8cdc7c5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/dashboard/users</value>
      <webElementGuid>c0b5e1e4-ee85-43be-9c0a-99c67b5e3651</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Manage Users</value>
      <webElementGuid>5c79eefe-c538-4227-9e55-8108c498a484</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[@class=&quot;App&quot;]/section[@class=&quot;ant-layout css-1i536d8&quot;]/section[@class=&quot;ant-layout ant-layout-has-sider css-1i536d8&quot;]/aside[@class=&quot;ant-layout-sider ant-layout-sider-dark ant-layout-sider-has-trigger&quot;]/div[@class=&quot;ant-layout-sider-children&quot;]/ul[@class=&quot;ant-menu ant-menu-root ant-menu-inline ant-menu-light css-1i536d8&quot;]/li[@class=&quot;ant-menu-item ant-menu-item-active&quot;]/span[@class=&quot;ant-menu-title-content&quot;]/a[1]</value>
      <webElementGuid>61846e4c-822d-4f52-88a2-75b2b86a4758</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div/section/section/aside/div/ul/li[3]/span[2]/a</value>
      <webElementGuid>293a19a2-1b20-46f7-9af2-d34769c524f8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Manage Users')]</value>
      <webElementGuid>64904e0b-8452-4fee-947f-b842d68060ad</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Manage Threads'])[1]/following::a[1]</value>
      <webElementGuid>e94080a3-5da7-4eee-a673-535ab81af07b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Dashboard'])[1]/following::a[2]</value>
      <webElementGuid>0a8c135b-4d4c-41b4-a433-321cca157a0d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Logout'])[1]/preceding::a[1]</value>
      <webElementGuid>cd31ee9b-6b63-4c07-be33-fa67fe6c89d0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='admin'])[1]/preceding::a[2]</value>
      <webElementGuid>e7816776-c71c-4bc0-91c7-57dc1347c759</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Manage Users']/parent::*</value>
      <webElementGuid>4a1f5b33-dfa2-4c95-b407-6137ee69fd26</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/dashboard/users')]</value>
      <webElementGuid>aeb3789a-0db7-4e58-88c7-3a19099f7044</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[3]/span[2]/a</value>
      <webElementGuid>5c6313dd-c58a-4331-a428-9e33716a0147</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/dashboard/users' and (text() = 'Manage Users' or . = 'Manage Users')]</value>
      <webElementGuid>aadd69a4-c292-4f0d-8f91-9defa1e54cf1</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
