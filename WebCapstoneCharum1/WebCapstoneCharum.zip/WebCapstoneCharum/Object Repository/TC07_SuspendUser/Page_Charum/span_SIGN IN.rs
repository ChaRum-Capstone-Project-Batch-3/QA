<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_SIGN IN</name>
   <tag></tag>
   <elementGuidId>dafb0656-3a89-40d0-aeca-9ba169013348</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div/section/div/div/div[2]/div[2]/form/div[4]/button/span</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>button.ant-btn.css-1i536d8.ant-btn-primary > span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>d29c5c46-72c2-4fcd-965d-21872d21ba29</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>SIGN IN</value>
      <webElementGuid>ef6d89e5-118d-4afa-9fd0-5d6762257eb1</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[@class=&quot;App&quot;]/section[@class=&quot;ant-layout css-1i536d8&quot;]/div[@class=&quot;box&quot;]/div[@class=&quot;ant-row row-main css-1i536d8&quot;]/div[@class=&quot;ant-col ant-col-13 col-2 css-1i536d8&quot;]/div[@class=&quot;form-input&quot;]/form[1]/div[@class=&quot;btn-submit&quot;]/button[@class=&quot;ant-btn css-1i536d8 ant-btn-primary&quot;]/span[1]</value>
      <webElementGuid>f4107a6f-d4c3-4629-981d-1a31b25948f9</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div/section/div/div/div[2]/div[2]/form/div[4]/button/span</value>
      <webElementGuid>f02be790-c019-48c8-b593-c4d62d50b742</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Keep me signed in'])[1]/following::span[1]</value>
      <webElementGuid>f5e17f46-a7e1-45dc-86fd-3dadc6a57afd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Password'])[1]/following::span[2]</value>
      <webElementGuid>5a367090-615d-46a9-afa2-108aa338e31a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Reset Password'])[1]/preceding::span[1]</value>
      <webElementGuid>dc6d9e6d-9d11-4a50-b44d-7c4e051cc43d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='SIGN IN']/parent::*</value>
      <webElementGuid>705a6a4a-fc2b-4cde-aded-dac8edae37d7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//button/span</value>
      <webElementGuid>1816bfb0-f4ab-4226-89bf-62fa5f4b99ea</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'SIGN IN' or . = 'SIGN IN')]</value>
      <webElementGuid>cba78e69-06a7-43fa-8a05-9c6527a32252</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
