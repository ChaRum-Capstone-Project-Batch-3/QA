<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Lihat Topik</name>
   <tag></tag>
   <elementGuidId>59c20c9f-676a-4203-84c9-33f654c9f008</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div/section/section/section/main/div/div/div/div/button/span</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>button.ant-btn.css-1i536d8.ant-btn-primary.ant-btn-lg.btn-header > span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>4119e72e-b243-4b6e-9b26-60753c571305</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Lihat Topik</value>
      <webElementGuid>37ff9e03-b92c-488d-b03e-39dfc283e0a2</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[@class=&quot;App&quot;]/section[@class=&quot;ant-layout css-1i536d8&quot;]/section[@class=&quot;ant-layout ant-layout-has-sider css-1i536d8&quot;]/section[@class=&quot;ant-layout site-layout css-1i536d8&quot;]/main[@class=&quot;ant-layout-content&quot;]/div[@class=&quot;site-layout-background&quot;]/div[@class=&quot;content-main&quot;]/div[@class=&quot;header-content&quot;]/div[@class=&quot;text-head-content&quot;]/button[@class=&quot;ant-btn css-1i536d8 ant-btn-primary ant-btn-lg btn-header&quot;]/span[1]</value>
      <webElementGuid>640a4eed-a395-4ab2-8566-a5cff1a3e705</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div/section/section/section/main/div/div/div/div/button/span</value>
      <webElementGuid>2070d5e0-1716-4912-a02a-c069314ef5b4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Hello Vinka!'])[1]/following::span[1]</value>
      <webElementGuid>c72171c5-0c1e-4ac9-b1fa-271d2b23407e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='/'])[1]/following::span[2]</value>
      <webElementGuid>ef067a35-545a-43c0-bf9d-3193ec054769</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Lihat Topik']/parent::*</value>
      <webElementGuid>f92f74fa-76ac-46e2-9fdf-93f9a5655bb0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//button/span</value>
      <webElementGuid>e9f1e054-6f78-4b35-bd55-d076d3a305f7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Lihat Topik' or . = 'Lihat Topik')]</value>
      <webElementGuid>7af6baff-57ae-4b04-96d5-23097a6d5035</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
