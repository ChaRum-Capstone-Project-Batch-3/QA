<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_SIGN IN</name>
   <tag></tag>
   <elementGuidId>193dfb73-9cab-4b7a-8ecd-23c0dd70182e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div/section/div/div/div[2]/div[2]/form/div[4]/button/span</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>button.ant-btn.css-1i536d8.ant-btn-primary > span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>43d42eaa-f509-4ff1-aff3-dc5fc9c28069</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>SIGN IN</value>
      <webElementGuid>478e2ced-300d-4a0d-8f1c-b7ee53ca8136</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[@class=&quot;App&quot;]/section[@class=&quot;ant-layout css-1i536d8&quot;]/div[@class=&quot;box&quot;]/div[@class=&quot;ant-row row-main css-1i536d8&quot;]/div[@class=&quot;ant-col ant-col-13 col-2 css-1i536d8&quot;]/div[@class=&quot;form-input&quot;]/form[1]/div[@class=&quot;btn-submit&quot;]/button[@class=&quot;ant-btn css-1i536d8 ant-btn-primary&quot;]/span[1]</value>
      <webElementGuid>ac4fe0e6-4ed5-45ba-a1d5-ab7b9fe7b22d</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div/section/div/div/div[2]/div[2]/form/div[4]/button/span</value>
      <webElementGuid>051f4e02-f6ae-4b16-ac73-13fc96864ee7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Keep me signed in'])[1]/following::span[1]</value>
      <webElementGuid>0d1ba100-fb5e-47b0-b68e-bda8b9a3f830</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Password'])[1]/following::span[2]</value>
      <webElementGuid>45fe3b68-8765-4574-9388-330c112752a6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Reset Password'])[1]/preceding::span[1]</value>
      <webElementGuid>6f34fc07-04ef-4c59-86a0-14034ca24574</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='SIGN IN']/parent::*</value>
      <webElementGuid>fa07c87b-58f9-4d0b-81a8-ada7dc7fd35e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//button/span</value>
      <webElementGuid>0e47dc6b-b0c9-41b6-966f-ab4309528817</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'SIGN IN' or . = 'SIGN IN')]</value>
      <webElementGuid>d707539b-c143-4be0-b700-dbf177b6ac57</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
