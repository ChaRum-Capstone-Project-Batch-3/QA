<?xml version="1.0" encoding="UTF-8"?>
<WebServiceRequestEntity>
   <description></description>
   <name>Suspend user</name>
   <tag></tag>
   <elementGuidId>4a565ed8-2f85-453b-afa9-fef44c84608d</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <authorizationRequest>
      <authorizationInfo>
         <entry>
            <key>bearerToken</key>
            <value>eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1aWQiOiI2MzdmNjg3ZDVlOTJmMTFkZmFkZmNjNTEiLCJpc3MiOiJjaGFydW0iLCJleHAiOjE2NzE1MzM0NTAsIm5iZiI6MTY3MTUyNjI1MCwiaWF0IjoxNjcxNTI2MjUwfQ.H2laKdnjM-LnObvbSS7RqNUNrOw0bUMOdvP4zdYZURc</value>
         </entry>
      </authorizationInfo>
      <authorizationType>Bearer</authorizationType>
   </authorizationRequest>
   <connectionTimeout>-1</connectionTimeout>
   <followRedirects>false</followRedirects>
   <httpBody></httpBody>
   <httpBodyContent></httpBodyContent>
   <httpBodyType></httpBodyType>
   <httpHeaderProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>Accept</name>
      <type>Main</type>
      <value>application/json</value>
      <webElementGuid>65c88419-7f43-45df-982f-029d4acc4d3d</webElementGuid>
   </httpHeaderProperties>
   <httpHeaderProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>Authorization</name>
      <type>Main</type>
      <value>Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1aWQiOiI2MzdmNjg3ZDVlOTJmMTFkZmFkZmNjNTEiLCJpc3MiOiJjaGFydW0iLCJleHAiOjE2NzE1MzM0NTAsIm5iZiI6MTY3MTUyNjI1MCwiaWF0IjoxNjcxNTI2MjUwfQ.H2laKdnjM-LnObvbSS7RqNUNrOw0bUMOdvP4zdYZURc</value>
      <webElementGuid>26238aa1-0c2a-4610-98d7-dc383896637d</webElementGuid>
   </httpHeaderProperties>
   <katalonVersion>8.5.2</katalonVersion>
   <maxResponseSize>-1</maxResponseSize>
   <migratedVersion>5.4.1</migratedVersion>
   <restRequestMethod>PUT</restRequestMethod>
   <restUrl>https://charum-api.nyakit.in/api/v1/admin/user/suspend/63942ad55b1979ce0e7a15a3</restUrl>
   <serviceType>RESTful</serviceType>
   <soapBody></soapBody>
   <soapHeader></soapHeader>
   <soapRequestMethod></soapRequestMethod>
   <soapServiceEndpoint></soapServiceEndpoint>
   <soapServiceFunction></soapServiceFunction>
   <socketTimeout>-1</socketTimeout>
   <useServiceInfoFromWsdl>true</useServiceInfoFromWsdl>
   <variables>
      <defaultValue>'63942ad55b1979ce0e7a15a3'</defaultValue>
      <description>(Required) user ID</description>
      <id>2bbd62f1-1808-47a3-9c39-bcc67c51fa2c</id>
      <masked>false</masked>
      <name>user-id</name>
   </variables>
   <verificationScript>import static org.assertj.core.api.Assertions.*

import com.kms.katalon.core.testobject.RequestObject
import com.kms.katalon.core.testobject.ResponseObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webservice.verification.WSResponseManager

import groovy.json.JsonSlurper
import internal.GlobalVariable as GlobalVariable

RequestObject request = WSResponseManager.getInstance().getCurrentRequest()

ResponseObject response = WSResponseManager.getInstance().getCurrentResponse()</verificationScript>
   <wsdlAddress></wsdlAddress>
</WebServiceRequestEntity>
