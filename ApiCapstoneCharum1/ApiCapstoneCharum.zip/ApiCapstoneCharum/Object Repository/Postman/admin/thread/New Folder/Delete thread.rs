<?xml version="1.0" encoding="UTF-8"?>
<WebServiceRequestEntity>
   <description></description>
   <name>Delete thread</name>
   <tag></tag>
   <elementGuidId>b3ff1204-69e2-4ee0-8cd7-c51c45f6efb5</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <authorizationRequest>
      <authorizationInfo>
         <entry>
            <key>bearerToken</key>
            <value>eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1aWQiOiI2MzdmNjg3ZDVlOTJmMTFkZmFkZmNjNTEiLCJpc3MiOiJjaGFydW0iLCJleHAiOjE2NzE1NTM2OTUsIm5iZiI6MTY3MTU0NjQ5NSwiaWF0IjoxNjcxNTQ2NDk1fQ.VEqVLjO1ONrvT_zjoZ_XscfnZDUQMgalMucPin8_EKU</value>
         </entry>
      </authorizationInfo>
      <authorizationType>Bearer</authorizationType>
   </authorizationRequest>
   <connectionTimeout>-1</connectionTimeout>
   <followRedirects>false</followRedirects>
   <httpBody></httpBody>
   <httpBodyContent></httpBodyContent>
   <httpBodyType></httpBodyType>
   <httpHeaderProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>Accept</name>
      <type>Main</type>
      <value>application/json</value>
      <webElementGuid>85c0de87-06d6-4dcb-b281-6fe92ae08552</webElementGuid>
   </httpHeaderProperties>
   <httpHeaderProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>Authorization</name>
      <type>Main</type>
      <value>Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1aWQiOiI2MzdmNjg3ZDVlOTJmMTFkZmFkZmNjNTEiLCJpc3MiOiJjaGFydW0iLCJleHAiOjE2NzE1NTM2OTUsIm5iZiI6MTY3MTU0NjQ5NSwiaWF0IjoxNjcxNTQ2NDk1fQ.VEqVLjO1ONrvT_zjoZ_XscfnZDUQMgalMucPin8_EKU</value>
      <webElementGuid>0f65392e-83e4-4564-b50e-5e1488b23432</webElementGuid>
   </httpHeaderProperties>
   <katalonVersion>8.5.2</katalonVersion>
   <maxResponseSize>-1</maxResponseSize>
   <migratedVersion>5.4.1</migratedVersion>
   <restRequestMethod>DELETE</restRequestMethod>
   <restUrl>https://charum-api.nyakit.in/api/v1/admin/thread/id/1</restUrl>
   <serviceType>RESTful</serviceType>
   <soapBody></soapBody>
   <soapHeader></soapHeader>
   <soapRequestMethod></soapRequestMethod>
   <soapServiceEndpoint></soapServiceEndpoint>
   <soapServiceFunction></soapServiceFunction>
   <socketTimeout>-1</socketTimeout>
   <useServiceInfoFromWsdl>true</useServiceInfoFromWsdl>
   <variables>
      <defaultValue>'639bf675fd1cd9847a8fc4ce'</defaultValue>
      <description>(Required) thread id</description>
      <id>cb200a49-b5d4-4ac4-8a50-645bff6ef1f3</id>
      <masked>false</masked>
      <name>thread-id</name>
   </variables>
   <verificationScript>import static org.assertj.core.api.Assertions.*

import com.kms.katalon.core.testobject.RequestObject
import com.kms.katalon.core.testobject.ResponseObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webservice.verification.WSResponseManager

import groovy.json.JsonSlurper
import internal.GlobalVariable as GlobalVariable

RequestObject request = WSResponseManager.getInstance().getCurrentRequest()

ResponseObject response = WSResponseManager.getInstance().getCurrentResponse()</verificationScript>
   <wsdlAddress></wsdlAddress>
</WebServiceRequestEntity>
