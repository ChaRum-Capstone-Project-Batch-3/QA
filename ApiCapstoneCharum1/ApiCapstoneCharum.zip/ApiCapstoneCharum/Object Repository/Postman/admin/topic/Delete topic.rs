<?xml version="1.0" encoding="UTF-8"?>
<WebServiceRequestEntity>
   <description></description>
   <name>Delete topic</name>
   <tag></tag>
   <elementGuidId>f1572610-658f-4071-b64d-05604b7d90f3</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <authorizationRequest>
      <authorizationInfo>
         <entry>
            <key>bearerToken</key>
            <value>eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1aWQiOiI2MzdmNjg3ZDVlOTJmMTFkZmFkZmNjNTEiLCJpc3MiOiJjaGFydW0iLCJleHAiOjE2NzE1NDk4NzQsIm5iZiI6MTY3MTU0MjY3NCwiaWF0IjoxNjcxNTQyNjc0fQ.BlVJBZuoFiFEonGxoNo7ASV_kiJgQ5Bc0GPp8IwXQDo</value>
         </entry>
      </authorizationInfo>
      <authorizationType>Bearer</authorizationType>
   </authorizationRequest>
   <connectionTimeout>-1</connectionTimeout>
   <followRedirects>false</followRedirects>
   <httpBody></httpBody>
   <httpBodyContent></httpBodyContent>
   <httpBodyType></httpBodyType>
   <httpHeaderProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>Accept</name>
      <type>Main</type>
      <value>application/json</value>
      <webElementGuid>1222040f-fec3-49fb-b45d-428b5f01b6d0</webElementGuid>
   </httpHeaderProperties>
   <httpHeaderProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>Authorization</name>
      <type>Main</type>
      <value>Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1aWQiOiI2MzdmNjg3ZDVlOTJmMTFkZmFkZmNjNTEiLCJpc3MiOiJjaGFydW0iLCJleHAiOjE2NzE1NDk4NzQsIm5iZiI6MTY3MTU0MjY3NCwiaWF0IjoxNjcxNTQyNjc0fQ.BlVJBZuoFiFEonGxoNo7ASV_kiJgQ5Bc0GPp8IwXQDo</value>
      <webElementGuid>43de4de8-f653-4d0c-9a29-a29c6fc677f5</webElementGuid>
   </httpHeaderProperties>
   <katalonVersion>8.5.2</katalonVersion>
   <maxResponseSize>-1</maxResponseSize>
   <migratedVersion>5.4.1</migratedVersion>
   <restRequestMethod>DELETE</restRequestMethod>
   <restUrl>https://charum-api.nyakit.in/api/v1/admin/topic/id/639df3e4fd1cd9847a8fc4e0</restUrl>
   <serviceType>RESTful</serviceType>
   <soapBody></soapBody>
   <soapHeader></soapHeader>
   <soapRequestMethod></soapRequestMethod>
   <soapServiceEndpoint></soapServiceEndpoint>
   <soapServiceFunction></soapServiceFunction>
   <socketTimeout>-1</socketTimeout>
   <useServiceInfoFromWsdl>true</useServiceInfoFromWsdl>
   <variables>
      <defaultValue>'639df3e4fd1cd9847a8fc4e0'</defaultValue>
      <description>(Required) topic ID</description>
      <id>d70a96ba-1af2-4df1-a4f4-6a0c8531d26c</id>
      <masked>false</masked>
      <name>topic-id</name>
   </variables>
   <verificationScript>import static org.assertj.core.api.Assertions.*

import com.kms.katalon.core.testobject.RequestObject
import com.kms.katalon.core.testobject.ResponseObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webservice.verification.WSResponseManager

import groovy.json.JsonSlurper
import internal.GlobalVariable as GlobalVariable

RequestObject request = WSResponseManager.getInstance().getCurrentRequest()

ResponseObject response = WSResponseManager.getInstance().getCurrentResponse()</verificationScript>
   <wsdlAddress></wsdlAddress>
</WebServiceRequestEntity>
