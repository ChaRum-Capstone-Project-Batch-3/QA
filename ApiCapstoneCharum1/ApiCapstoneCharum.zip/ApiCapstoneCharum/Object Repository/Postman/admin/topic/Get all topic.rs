<?xml version="1.0" encoding="UTF-8"?>
<WebServiceRequestEntity>
   <description></description>
   <name>Get all topic</name>
   <tag></tag>
   <elementGuidId>df345456-b4c4-457a-aeb2-2ffc75334f81</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <authorizationRequest>
      <authorizationInfo>
         <entry>
            <key>bearerToken</key>
            <value>eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1aWQiOiI2MzdmNjg3ZDVlOTJmMTFkZmFkZmNjNTEiLCJpc3MiOiJjaGFydW0iLCJleHAiOjE2NzE1NDk4NzQsIm5iZiI6MTY3MTU0MjY3NCwiaWF0IjoxNjcxNTQyNjc0fQ.BlVJBZuoFiFEonGxoNo7ASV_kiJgQ5Bc0GPp8IwXQDo</value>
         </entry>
      </authorizationInfo>
      <authorizationType>Bearer</authorizationType>
   </authorizationRequest>
   <connectionTimeout>-1</connectionTimeout>
   <followRedirects>false</followRedirects>
   <httpBody></httpBody>
   <httpBodyContent></httpBodyContent>
   <httpBodyType></httpBodyType>
   <httpHeaderProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>Accept</name>
      <type>Main</type>
      <value>application/json</value>
      <webElementGuid>d75d1904-654d-4db8-b8fc-ec6d0801e6f3</webElementGuid>
   </httpHeaderProperties>
   <httpHeaderProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>Authorization</name>
      <type>Main</type>
      <value>Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1aWQiOiI2MzdmNjg3ZDVlOTJmMTFkZmFkZmNjNTEiLCJpc3MiOiJjaGFydW0iLCJleHAiOjE2NzE1NDk4NzQsIm5iZiI6MTY3MTU0MjY3NCwiaWF0IjoxNjcxNTQyNjc0fQ.BlVJBZuoFiFEonGxoNo7ASV_kiJgQ5Bc0GPp8IwXQDo</value>
      <webElementGuid>61731826-f37d-4c04-92b6-3995c01ae578</webElementGuid>
   </httpHeaderProperties>
   <katalonVersion>8.5.2</katalonVersion>
   <maxResponseSize>-1</maxResponseSize>
   <migratedVersion>5.4.1</migratedVersion>
   <restRequestMethod>GET</restRequestMethod>
   <restUrl>https://charum-api.nyakit.in/api/v1/admin/topic/1?limit=25&amp;sort=createdAt&amp;order=desc&amp;topic=Business</restUrl>
   <serviceType>RESTful</serviceType>
   <soapBody></soapBody>
   <soapHeader></soapHeader>
   <soapRequestMethod></soapRequestMethod>
   <soapServiceEndpoint></soapServiceEndpoint>
   <soapServiceFunction></soapServiceFunction>
   <socketTimeout>-1</socketTimeout>
   <useServiceInfoFromWsdl>true</useServiceInfoFromWsdl>
   <verificationScript>import static org.assertj.core.api.Assertions.*

import com.kms.katalon.core.testobject.RequestObject
import com.kms.katalon.core.testobject.ResponseObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webservice.verification.WSResponseManager

import groovy.json.JsonSlurper
import internal.GlobalVariable as GlobalVariable

RequestObject request = WSResponseManager.getInstance().getCurrentRequest()

ResponseObject response = WSResponseManager.getInstance().getCurrentResponse()</verificationScript>
   <wsdlAddress></wsdlAddress>
</WebServiceRequestEntity>
